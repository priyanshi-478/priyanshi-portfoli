import React from 'react';

const About = () => {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
          <div className="mb-12 lg:mb-0">
          
             
          </div>
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">About Me</h2>
            <p className="text-lg text-gray-600 mb-6">
             I an enthusiastic explorer who loves learning new things, especially in coding, with skills in Java and C++ programming. 
            </p>
            <p className="text-lg text-gray-600 mb-6">
              My goal is to create beautiful, functional, and user-friendly applications that solve
              real-world problems. I'm constantly learning new technologies and best practices to
              stay web development.
            </p>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Education</h3>
                <p className="text-gray-600">B.C.A. in Computer Application</p>
                <p className="text-gray-500">Galgotias University</p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Experience</h3>
                <p className="text-gray-600">Senior member in college </p>
                <p className="text-gray-500"> Graphic design</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;