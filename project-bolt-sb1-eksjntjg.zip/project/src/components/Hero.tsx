import React from 'react';
import { ArrowRight } from 'lucide-react';

const Hero = () => {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-50 via-white to-indigo-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 text-center">
        <h1 className="text-4xl sm:text-6xl font-bold text-gray-900 mb-6">
          Hi, I'm <span className="text-indigo-600">Priyanshi Agrawal</span>
        </h1>
        <p className="text-xl sm:text-2xl text-gray-600 mb-8">
          Full Stack Developer | UI/UX Designer | Tech Enthusiast
        </p>
        <div className="flex justify-center gap-4">
          <a
            href="#contact"
            className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
          >
            Contact Me
            <ArrowRight className="ml-2 h-5 w-5" />
          </a>
          <a
            href="#projects"
            className="inline-flex items-center px-6 py-3 border border-gray-300 text-base font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
          >
            View Projects
          </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;